# VitAI Non-Prod BigQuery provisioning (offline preparation)

Target project: `tps-prv1-cmlkr-np-w8k`.

1. Keep source metadata CSVs on the approved company workstation. Do not copy restricted DDL into an unapproved GitHub repo.
2. Confirm `europe-west2` is approved for **each** destination dataset. Change `--region` if needed; this script assumes one common region.
3. Copy `github_migration_manifest_nonprod.csv` into the approved local working directory.
4. Run `py -3 prepare_nonprod.py --manifest github_migration_manifest_nonprod.csv --metadata input/metadata --out generated`. The `input/metadata` folder should contain the local source metadata exports.
5. Review `generated/holds.csv` and `generated/summary.txt`. No cloud changes have been made.
6. After approval, run `generated/01_create_datasets.sql` in **VitAI Non-Prod** BigQuery.
7. Review table DDL carefully and run `02_create_tables_REVIEW.sql` only after checking schema/permissions/partitioning. This creates **empty tables**, not data.
8. Resolve view dependencies, cross-project references and holds before running `03_create_views_REVIEW.sql`.
9. Verify actual table/view existence, schema, row availability and Looker Studio connections before marking anything deployed.

**Safety:** Do not run CREATE statements against Quantium. Do not use CREATE OR REPLACE or copy production data automatically. Do not interpret a source match as a destination validation. The original manifest has 45 retained references and 44 unique objects, with three unverified references held.
