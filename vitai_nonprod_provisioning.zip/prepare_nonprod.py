"""Offline, metadata-only VitAI Non-Prod provisioning planner. No GCP calls.
Run: py -3 prepare_nonprod.py --manifest config/github_migration_manifest.csv --metadata input/metadata --out generated
"""
import argparse,csv,re
from pathlib import Path
from collections import defaultdict
PROJECT='tps-prv1-cmlkr-np-w8k'
FQN=re.compile(r'(?is)^\s*CREATE\s+(?:OR\s+REPLACE\s+)?(?:EXTERNAL\s+)?(?:TABLE|VIEW|MATERIALIZED\s+VIEW|SNAPSHOT\s+TABLE)\s+(?:IF\s+NOT\s+EXISTS\s+)?`[^`]+`')
def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',required=True,type=Path);p.add_argument('--metadata',required=True,type=Path);p.add_argument('--out',default=Path('generated'),type=Path);p.add_argument('--region',default='europe-west2');a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True)
    rows=read_csv(a.manifest)
    required={'source_project','source_dataset','source_object','source_match_status'}
    if not rows or not required.issubset(rows[0]):raise SystemExit('ERROR: manifest missing expected fields')
    selected={}; holds=[]
    for r in rows:
        key=tuple(r[k].strip() for k in ('source_project','source_dataset','source_object'))
        if r['source_match_status'].strip()!='EXACT_MATCH':holds.append((key,'SOURCE_NOT_VERIFIED'));continue
        if key in selected:continue
        selected[key]=r
    catalog=defaultdict(list)
    for file in sorted(a.metadata.glob('*.csv')):
        for r in read_csv(file):
            if not {'source_project','source_dataset','source_object','create_statement'}.issubset(r):continue
            key=tuple(r[k].strip() for k in ('source_project','source_dataset','source_object'))
            catalog[key].append(r)
    dataset_sql=['-- Review dataset locations and permissions BEFORE running.','-- Non-Prod only. Does not copy data.','']
    for ds in sorted({k[1] for k in selected}):
        dataset_sql.append(f"CREATE SCHEMA IF NOT EXISTS `{PROJECT}.{ds}` OPTIONS(location='{a.region}');")
    (a.out/'01_create_datasets.sql').write_text('\n'.join(dataset_sql)+'\n',encoding='utf-8')
    tables=[];views=[];report=[]
    for key,r in sorted(selected.items()):
        matches=catalog.get(key,[])
        if not matches:
            holds.append((key,'DDL_NOT_IN_LOCAL_EXPORTS'));continue
        ddls={m.get('create_statement','').strip() for m in matches if m.get('create_statement','').strip()}
        if len(ddls)!=1:
            holds.append((key,'MISSING_OR_CONFLICTING_DDL'));continue
        ddl=next(iter(ddls));dst=f'{PROJECT}.{key[1]}.{key[2]}'
        if not FQN.match(ddl):
            holds.append((key,'UNSUPPORTED_CREATE_SYNTAX'));continue
        rewritten=FQN.sub(lambda m: re.sub(r'`[^`]+`$',lambda _: '`'+dst+'`',m.group(0)),ddl,count=1)
        # Prevent accidental dependency on source projects; requires human rewrite.
        if 'd-vzaeng-prd-sqr2' in rewritten or 'd-vzasci-prd-lghi' in rewritten:
            holds.append((key,'SOURCE_PROJECT_REFERENCE_IN_DDL'));continue
        typ=matches[0].get('object_type','').upper()
        if typ=='BASE TABLE':tables.append('-- '+dst+'\n'+rewritten.rstrip(';')+';')
        elif typ=='VIEW':views.append('-- '+dst+'\n'+rewritten.rstrip(';')+';')
        else:holds.append((key,'OBJECT_TYPE_REQUIRES_REVIEW'));continue
        report.append(dst)
    (a.out/'02_create_tables_REVIEW.sql').write_text('-- Review schemas, partitioning, IAM, dependencies. Empty tables only.\n\n'+'\n\n'.join(tables)+'\n',encoding='utf-8')
    (a.out/'03_create_views_REVIEW.sql').write_text('-- REVIEW view dependencies and source references before executing.\n\n'+'\n\n'.join(views)+'\n',encoding='utf-8')
    with (a.out/'holds.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.writer(f);w.writerow(['source_project','source_dataset','source_object','reason']);w.writerows([(*k,why) for k,why in holds])
    (a.out/'summary.txt').write_text(f'Non-Prod destination: {PROJECT}\nSource rows: {len(rows)}\nUnique exact-match objects: {len(selected)}\nDatasets: {len(set(k[1] for k in selected))}\nTable DDL prepared: {len(tables)}\nView DDL prepared: {len(views)}\nHeld entries: {len(holds)}\nNO CLOUD ACTIONS PERFORMED\n',encoding='utf-8')
    print((a.out/'summary.txt').read_text());print('Review generated/holds.csv before running any DDL.')
if __name__=='__main__':main()
