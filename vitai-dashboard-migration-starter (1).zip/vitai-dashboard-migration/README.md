# VitAI dashboard-only migration

**Scope:** Rebuild/replicate Quantium Looker Studio reports in VitAI Looker Studio, reusing **existing** BigQuery datasets/tables. No BigQuery dataset creation, table copying, or data movement.

## What this starter actually does

- Stores dashboard inventory and approved `project.dataset.table` mappings in `config/dashboards.json`.
- Checks manifest syntax on pull requests.
- On manual workflow dispatch, authenticates to GCP through GitHub OIDC / Workload Identity Federation and uses the BigQuery metadata API to confirm existing tables and optional required fields.
- Produces `reports/validation.json` as a GitHub Actions artifact.
- Does **not** automatically export, import, copy, or deploy Looker Studio reports. Those steps require an approved supported API route or a controlled UI rebuild.

## Configuration

1. Replace the blank report URLs and populate `sources` from the **approved, non-red** rows of the internal source workbook. Keep the workbook within authorized company systems.
2. Each source entry has the form:

   ```json
   {"table_fqn":"existing-project.existing_dataset.EXISTING_TABLE","required_fields":["FIELD_NAME"]}
   ```

3. Configure GitHub environments `nonprod` and `prod` with required reviewers for production.
4. Configure each environment's **variables** (not secrets):
   - `WIF_PROVIDER`: full Workload Identity Provider resource path.
   - `GCP_CICD_SERVICE_ACCOUNT`: dedicated, keyless CI/CD service account email.
   - `BQ_BILLING_PROJECT`: approved project for BigQuery client initialization.
5. Admin must grant repository-restricted GitHub WIF principal `roles/iam.workloadIdentityUser` on the CI/CD SA. SA needs `roles/bigquery.metadataViewer` on approved existing datasets/tables; `roles/bigquery.jobUser` on the query project only if executing SQL validation jobs (this starter uses metadata API and does not submit query jobs).
6. Run **Actions → Validate dashboard connections → Run workflow → nonprod**. Review JSON artifact. Production only after nonprod passes.

## Manual dashboard deployment gate

For each dashboard, inventory pages, chart types, fields, calculated fields, filters, blends, parameters, and connector credential mode. Rebuild in VitAI Looker Studio, attach existing BigQuery tables, and validate visuals and filter behavior. Record the destination report URL and status in the manifest. Do not mark a dashboard deployed solely because metadata checks pass.

## Security

- Do not put credentials, tokens, sensitive source data, or unapproved internal files in the repository.
- Workflow is read-only; no Terraform apply, DDL, DML, `bq cp`, or dataset creation.
- OIDC credentials are short-lived; do not create JSON service account keys.
- Restrict WIF by GitHub organization, repository, and production environment as appropriate.
