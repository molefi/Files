#!/usr/bin/env python3
"""Read-only dashboard manifest and BigQuery connection validation.

Never creates, modifies, copies, or deletes datasets/tables or reports.
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path

FQN = re.compile(r"^[a-z][a-z0-9-]{4,61}[a-z0-9]\.[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*$")
# BigQuery project IDs may also include numeric suffixes; see validation below.


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', default='config/dashboards.json')
    parser.add_argument('--check-bigquery', action='store_true')
    parser.add_argument('--report', default='reports/validation.json')
    args = parser.parse_args()
    manifest = json.loads(Path(args.manifest).read_text(encoding='utf-8'))
    dashboards = manifest.get('dashboards', [])
    if not isinstance(dashboards, list) or not dashboards:
        raise ValueError('Manifest must contain a nonempty dashboards list')
    client = None
    if args.check_bigquery:
        from google.cloud import bigquery
        client = bigquery.Client(project=os.environ.get('BQ_BILLING_PROJECT') or None)
    results = []
    failures = 0
    for dash in dashboards:
        entry = {'dashboard': dash.get('id'), 'name': dash.get('name'), 'status': dash.get('status'), 'sources': [], 'warnings': []}
        if not dash.get('source_report_url'):
            entry['warnings'].append('Source report URL not populated')
        if not dash.get('destination_report_url'):
            entry['warnings'].append('Destination report URL not populated')
        sources = dash.get('sources', [])
        if not sources:
            entry['warnings'].append('No approved BigQuery source mappings populated yet')
        for src in sources:
            fqn = src.get('table_fqn', '').strip('`')
            result = {'table_fqn': fqn, 'status': 'not_checked'}
            if not re.fullmatch(r'[a-z][a-z0-9-]{4,61}[a-z0-9]\.[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*', fqn):
                result.update(status='invalid_fqn', error='Expected project.dataset.table')
                failures += 1
            elif client:
                try:
                    table = client.get_table(fqn)
                    result.update(status='ok', fields=len(table.schema), table_type=table.table_type)
                    if src.get('required_fields'):
                        actual = {field.name.casefold() for field in table.schema}
                        missing = [field for field in src['required_fields'] if field.casefold() not in actual]
                        if missing:
                            result.update(status='missing_fields', missing_fields=missing)
                            failures += 1
                except Exception as exc:
                    result.update(status='error', error=str(exc))
                    failures += 1
            entry['sources'].append(result)
        results.append(entry)
    out = {'mode': 'bigquery_read_only' if client else 'manifest_only', 'dashboards': results, 'failures': failures}
    path = Path(args.report)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(out, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(out, indent=2))
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
